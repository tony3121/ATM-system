/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

/**
 *
 * @author Valentin
 */
public class Atm {
    
    protected static Integer number =1234;
    protected Integer pin;

    public Atm() {
    }

    public Atm(Integer pin) {
        this.pin = pin;
    }

    public static Integer getNumber() {
        return number;
    }

    public static void setNumber(Integer number) {
        Atm.number = number;
    }

    public Integer getPin() {
        return pin;
    }

    public void setPin(Integer pin) {
        this.pin = pin;
    }

    

   
    
    
    
}
