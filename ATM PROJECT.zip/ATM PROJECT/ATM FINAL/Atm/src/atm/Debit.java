/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

import java.util.ArrayList;

/**
 *
 * @author Valentin
 * Bibiliography:
 * https://stackoverflow.com/questions/4646577/global-variables-in-java
 * making a class global
 */
public class Debit extends Atm{
    
    protected static int balance=1000;//global variable
    protected static ArrayList <String> history = new ArrayList <String>();//creating a global string
    
    
    
}